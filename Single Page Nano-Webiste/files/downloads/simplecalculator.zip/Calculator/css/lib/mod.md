## Font Weight {300, 600, 900}
s-bold, s-bolder, s-boldest

## Font Style {italic}
s-italic