// Package/App Data
// App root
const app = {
    name : "SpectronX Calculator",

    author : "Ronaldo Excellent",

    logo : document.querySelector('application').getAttribute('logo'),

    theme : "magenta",

    mode : "light",

    projectStart : "5th December, 2023. 3:22PM",

    projectEnd : ""
};

// App Components
const elements = [];

const components = {};