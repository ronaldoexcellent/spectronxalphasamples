# CSS Extensions
All SpectronX Colors (Backgrounds/Themes) now have support for mobile, tablet and PC devices.
## Syntax
-s-sm-color || -s-md-color || -s-lg-color

# JS Folder
Package/js/source/library.cjs is now Package/js/source/spectronx.cjs

# HTML Source Update
<var> element is now validated and updates automatically...
## Syntax
HTML: <var name="myVar"></var>
JS: var myVar
You can also use the $ and _ symbols to declare the variables and add them to the <var> element...
## Syntax
HTML: <var name="$MyVar"></var>
JS: $MyVar

# SpectronX CSS
All strictness have been removed for easy manipulation with JS.

# SpectronXS {SpectronXServer}
This new version of SpectronX now lets you create dynamic components using the createComponent() function. See the sample package for better understanding...
Note: You'll need a server to properly run it.

# SpectronXS
Class manipulation functions (except addClass() & addClasses()) have now be modified as follows:
* removeClass() -> remClass()
* removeClasses() -> remClasses()
* repClass() -> repClass()
* repClasses() -> repClasses()
* toggleClass() -> togClass()
* toggleClasses() -> togClasses()

# New Framework
Now has Konva Framework. Please search Google for Konva.js to get a the knowledge and a better understanding about it.